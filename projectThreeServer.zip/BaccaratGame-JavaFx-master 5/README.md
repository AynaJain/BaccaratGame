# BaccaratGame-JavaFx

A networked version of popular casino game Baccarat using JavaFx.
